using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Pages
{
    public class LoginModel : PageModel
    {
        // Properties to hold the user input
        [BindProperty]
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        public string Email { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        // Property to hold error messages
        public string ErrorMessage { get; set; }

        public void OnGet()
        {
            // Handle GET requests (e.g., initialization)
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page(); // Return the page with validation errors
            }

            // TODO: Implement your login logic here
            // For example, you could validate the user's credentials against a database.
            // If the login fails, set the ErrorMessage property:
            // ErrorMessage = "Invalid login attempt.";
            
            // Redirect to a different page on successful login
            return RedirectToPage("/Index"); // Change this to your desired redirect page
        }
    }
}
